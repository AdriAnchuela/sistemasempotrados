#ifndef FCDAuxH
#define FCDAuxH
class CDAux{
	
	public:
		int a;
		int b;
		CDAux(int x, int y){
			a=x;
			b=y;
		}
				
	protected:
	
	private:
	
};
#endif
