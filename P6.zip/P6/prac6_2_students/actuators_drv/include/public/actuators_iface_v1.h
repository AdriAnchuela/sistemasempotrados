/*
 * actuators.h
 *
 *  Created on: May 4, 2013
 *      Author: user
 */

#ifndef ACTUATORS_IFACE_H_
#define ACTUATORS_IFACE_H_

#include <public/actuators.h>


#endif /* ACTUATORS_H_ */
